const date = new Date();

let dateDynamic = date.getDate();
let monthDynamic = date.getMonth();
let yearDynamic = date.getFullYear();
console.log(yearDynamic);

const renderCalendar = () => {
  date.setDate(1);
  let dateDynamic = date.getDate();
  let monthDynamic = date.getMonth();
  let yearDynamic = date.getFullYear();

  const monthDays = document.querySelector(".days");
  const lastDay = new Date(date.getFullYear(), date.getMonth(), 0).getDate();
  const prevLastDay = new Date(date.getFullYear(), date.getMonth(), 0).getDate();
  const firstDayIndex = date.getDay();
  const lastDayIndex = new Date(date.getFullYear(), date.getMonth(), 0).getDay();
  const nextDays = 7 - lastDayIndex - 1;

  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  document.querySelector(".date h1").innerHTML = months[monthDynamic - 1] + " " + yearDynamic;

  // document.querySelector(".date p").innerHTML = new Date().toDateString();

  let days = "";

  for (let x = firstDayIndex; x > 0; x--) {
    days += `<div class="prev-date">${prevLastDay - x + 1}</div>`;
  }

  for (let i = 1; i <= lastDay; i++) {
    if (i === new Date().getDate() && date.getMonth() === new Date().getMonth()) {
      days += `<div class="today">${i}</div>`;
    } else {
      days += `<div>${i}</div>`;
    }
  }

  for (let j = 1; j <= nextDays; j++) {
    days += `<div class="next-date">${j}</div>`;
    monthDays.innerHTML = days;
  }
};

// second calendar js (just copy of above code)

const renderCalendar2 = () => {
  date.setDate(1);
  // let dateDynamic=date.getDate();
  const monthDynamic = date.getMonth();
  const yearDynamic = date.getFullYear();
  console.log(yearDynamic);
  const monthDays2 = document.querySelector(".days2");
  const lastDay2 = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  const prevLastDay2 = new Date(date.getFullYear(), date.getMonth(), 0).getDate();
  const firstDayIndex2 = date.getDay();
  const lastDayIndex2 = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDay();
  const nextDays2 = 7 - lastDayIndex2 - 1;

  const months2 = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  document.querySelector(".date2 h1").innerHTML = months2[monthDynamic] + " " + yearDynamic;

  // document.querySelector(".date p").innerHTML = new Date().toDateString();

  let days2 = "";

  for (let x = firstDayIndex2; x > 0; x--) {
    days2 += `<div class="prev-date">${prevLastDay2 - x + 1}</div>`;
  }

  for (let i = 1; i <= lastDay2; i++) {
    if (i === new Date().getDate() && date.getMonth() === new Date().getMonth()) {
      days2 += `<div class="today">${i}</div>`;
    } else {
      days2 += `<div>${i}</div>`;
    }
  }

  for (let j = 1; j <= nextDays2; j++) {
    days2 += `<div class="next-date">${j}</div>`;
    monthDays2.innerHTML = days2;
  }
};

document.querySelector(".prev").addEventListener("click", () => {
  date.setMonth(date.getMonth() - 1);
  renderCalendar();
  renderCalendar2();
});

document.querySelector(".next").addEventListener("click", () => {
  date.setMonth(date.getMonth() + 1);
  renderCalendar();
  renderCalendar2();
});

renderCalendar();
renderCalendar2();

$(document).ready(function () {
  $(document).on("click", ".calendar .days > div:not('.next-date')", function () {
    getSelectedDate($(this), ".calendar");
  });

  $(document).on("click", ".calendar2 .days2 > div:not('.next-date')", function () {
    getSelectedDate($(this), ".calendar2", "2");
  });
});

function getSelectedDate(ele, selector, concat) {
  const currDate = ele.text();
  $(`${selector} .days${concat || ""} > div`).each(function (index) {
    $(this).removeClass("selected");
  });
  ele.addClass("selected");
  const monthYear = $(`${selector} .date${concat || ""}  h1`).text();
  const selectedDate = `${currDate} ${monthYear}`;
  console.log(selectedDate);
}
